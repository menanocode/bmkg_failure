import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/weather_screen.dart';
import 'screens/earthquake_screen.dart';
import 'screens/news_screen.dart';  // Tambahkan ini
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gempa dan Cuaca',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
      routes: {
        '/weather': (context) => WeatherScreen(),
        '/earthquake': (context) => EarthquakeScreen(),
        '/news': (context) => NewsScreen(),  // Tambahkan ini
      },
    );
  }
}
